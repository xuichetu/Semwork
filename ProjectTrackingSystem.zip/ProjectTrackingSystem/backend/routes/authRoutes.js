const express = require('express');
const router = express.Router();
const { login, logout, verifyToken, refreshToken } = require('../controllers/authController');
const { authenticate } = require('../middleware/auth');

router.post('/login', login);
router.post('/logout', logout);
router.post('/verify-token', authenticate, verifyToken);
router.post('/refresh-token', refreshToken);

module.exports = router;
