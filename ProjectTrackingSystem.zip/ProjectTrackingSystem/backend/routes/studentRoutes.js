const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/studentController');
const { authenticate, requireRole } = require('../middleware/auth');
const { upload } = require('../middleware/upload');
const { ROLES } = require('../utils/constants');

router.use(authenticate, requireRole(ROLES.STUDENT));

// Project access
router.get('/projects', ctrl.getMyProjects);
router.get('/projects/:project_id/details', ctrl.getProjectDetails);
router.get('/projects/:project_id/stages', ctrl.getProjectStages);
router.get('/projects/:project_id/guidelines', ctrl.getGuidelines);
router.get('/projects/:project_id/announcements', ctrl.getAnnouncements);

// Progress tracking
router.get('/projects/:project_id/my-progress', ctrl.getMyProgress);
router.get('/projects/:project_id/my-stages', ctrl.getMyStages);
router.get('/projects/:project_id/stage/:stage_id/status', ctrl.getStageStatus);

// Document submission
router.post('/projects/:project_id/submit-document', upload.single('file'), ctrl.submitDocument);
router.get('/projects/:project_id/my-submissions', ctrl.getMySubmissions);
router.get('/submissions/:submission_id', ctrl.getSubmissionById);
router.get('/projects/:project_id/pending-documents', ctrl.getPendingDocuments);

// Feedback & revision
router.get('/submissions/:submission_id/feedback', ctrl.getSubmissionFeedback);
router.post('/projects/:project_id/submissions/:submission_id/resubmit', upload.single('file'), ctrl.resubmitDocument);
router.get('/submissions/:submission_id/version-history', ctrl.getVersionHistory);

// Dashboard
router.get('/dashboard', ctrl.getDashboard);
router.get('/projects/:project_id/deadline-status', ctrl.getDeadlineStatus);

module.exports = router;
