const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/teacherController');
const { authenticate, requireRole } = require('../middleware/auth');
const { uploadGuidelines } = require('../middleware/upload');
const { ROLES } = require('../utils/constants');

router.use(authenticate, requireRole(ROLES.TEACHER));

// Projects
router.post('/projects', ctrl.createProject);
router.get('/projects', ctrl.getProjects);
router.get('/projects/:project_id', ctrl.getProjectById);
router.put('/projects/:project_id', ctrl.updateProject);
router.delete('/projects/:project_id', ctrl.deleteProject);

// Guidelines
router.post('/projects/:project_id/guidelines', uploadGuidelines.single('guidelines_file'), ctrl.upsertGuidelines);
router.get('/projects/:project_id/guidelines', ctrl.getGuidelines);
router.put('/projects/:project_id/guidelines', uploadGuidelines.single('guidelines_file'), ctrl.upsertGuidelines);

// Stages
router.post('/projects/:project_id/stages', ctrl.createStage);
router.get('/projects/:project_id/stages', ctrl.getStages);
router.put('/projects/:project_id/stages/:stage_id', ctrl.updateStage);
router.delete('/projects/:project_id/stages/:stage_id', ctrl.deleteStage);

// Enrollment
router.post('/projects/:project_id/enroll-students', ctrl.enrollStudents);
router.get('/projects/:project_id/enrolled-students', ctrl.getEnrolledStudents);
router.get('/projects/:project_id/student/:student_id/progress', ctrl.getStudentProgressDetail);
router.delete('/projects/:project_id/student/:student_id', ctrl.removeStudent);

// Document review
router.get('/projects/:project_id/submissions', ctrl.getProjectSubmissions);
router.get('/submissions/:submission_id', ctrl.getSubmissionDetail);
router.post('/submissions/:submission_id/review', ctrl.reviewSubmission);
router.put('/submissions/:submission_id/status', ctrl.updateSubmissionStatus);
router.get('/projects/:project_id/pending-documents', ctrl.getPendingDocuments);

// Progress tracking
router.get('/projects/:project_id/progress-report', ctrl.getProjectProgressReport);
router.get('/projects/:project_id/student/:student_id/stages', ctrl.getStudentStages);
router.get('/projects/:project_id/stage/:stage_id/completion', ctrl.getStageCompletionList);
router.post('/projects/:project_id/stage/:stage_id/mark-completion', ctrl.markStageCompletion);

// Dashboard & analytics
router.get('/dashboard', ctrl.getDashboard);
router.get('/projects/:project_id/analytics', ctrl.getProjectAnalytics);

// Announcements
router.post('/projects/:project_id/announcements', ctrl.createAnnouncement);
router.get('/projects/:project_id/announcements', ctrl.getAnnouncements);
router.put('/announcements/:announcement_id', ctrl.updateAnnouncement);
router.delete('/announcements/:announcement_id', ctrl.deleteAnnouncement);

module.exports = router;
