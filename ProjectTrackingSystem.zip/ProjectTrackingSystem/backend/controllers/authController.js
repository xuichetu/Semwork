const bcrypt = require('bcrypt');
const db = require('../config/db');
const { signAccessToken, signRefreshToken, verifyRefreshToken } = require('../utils/jwt');
const { ROLES, MESSAGES } = require('../utils/constants');

// POST /api/auth/login  { loginId, password, role }
// loginId = unique_id for teacher, roll_number or email for student
async function login(req, res) {
  try {
    const { loginId, password, role } = req.body;
    if (!loginId || !password || !role) {
      return res.status(400).json({ success: false, message: 'loginId, password and role are required.' });
    }

    let user, table, idField, payloadExtra;

    if (role === ROLES.TEACHER) {
      const [rows] = await db.query(
        'SELECT * FROM teachers WHERE unique_id = ? OR email = ? LIMIT 1',
        [loginId, loginId]
      );
      user = rows[0];
      idField = 'teacher_id';
      payloadExtra = { name: user?.full_name };
    } else if (role === ROLES.STUDENT) {
      const [rows] = await db.query(
        'SELECT * FROM students WHERE roll_number = ? OR email = ? LIMIT 1',
        [loginId, loginId]
      );
      user = rows[0];
      idField = 'student_id';
      payloadExtra = { name: user?.student_name };
    } else {
      return res.status(400).json({ success: false, message: 'Invalid role specified.' });
    }

    if (!user) {
      return res.status(401).json({ success: false, message: MESSAGES.INVALID_CREDENTIALS });
    }

    const passwordMatches = await bcrypt.compare(password, user.password);
    if (!passwordMatches) {
      return res.status(401).json({ success: false, message: MESSAGES.INVALID_CREDENTIALS });
    }

    const tokenPayload = { id: user[idField], role, ...payloadExtra };
    const accessToken = signAccessToken(tokenPayload);
    const refreshToken = signRefreshToken(tokenPayload);

    delete user.password;

    return res.json({
      success: true,
      accessToken,
      refreshToken,
      user: { ...user, role },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function logout(req, res) {
  // Stateless JWT: client discards tokens. Placeholder for token blacklist if added later.
  return res.json({ success: true, message: 'Logged out successfully.' });
}

async function verifyToken(req, res) {
  // `authenticate` middleware already validated the token before reaching here.
  return res.json({ success: true, user: req.user });
}

async function refreshToken(req, res) {
  try {
    const { refreshToken: token } = req.body;
    if (!token) return res.status(400).json({ success: false, message: 'refreshToken is required.' });
    const decoded = verifyRefreshToken(token);
    const newAccessToken = signAccessToken({ id: decoded.id, role: decoded.role, name: decoded.name });
    return res.json({ success: true, accessToken: newAccessToken });
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Invalid or expired refresh token.' });
  }
}

module.exports = { login, logout, verifyToken, refreshToken };
