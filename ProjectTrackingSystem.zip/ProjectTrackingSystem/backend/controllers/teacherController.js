const db = require('../config/db');
const { MESSAGES } = require('../utils/constants');

// ---------- PROJECT MANAGEMENT ----------

async function createProject(req, res) {
  try {
    const { project_name, project_description, deadline, guidelines } = req.body;
    const teacherId = req.user.id;
    if (!project_name) return res.status(400).json({ success: false, message: 'project_name is required.' });

    const [result] = await db.query(
      `INSERT INTO projects (project_name, project_description, teacher_id, deadline, guidelines)
       VALUES (?, ?, ?, ?, ?)`,
      [project_name, project_description || null, teacherId, deadline || null, guidelines || null]
    );
    return res.status(201).json({ success: true, project_id: result.insertId });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getProjects(req, res) {
  try {
    const teacherId = req.user.id;
    const [projects] = await db.query(
      `SELECT p.*,
        (SELECT COUNT(*) FROM student_project_enrollment e WHERE e.project_id = p.project_id) AS enrolled_count
       FROM projects p WHERE p.teacher_id = ? ORDER BY p.created_date DESC`,
      [teacherId]
    );
    return res.json({ success: true, projects });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getProjectById(req, res) {
  try {
    const { project_id } = req.params;
    const [rows] = await db.query('SELECT * FROM projects WHERE project_id = ? AND teacher_id = ?', [
      project_id,
      req.user.id,
    ]);
    if (!rows.length) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });
    return res.json({ success: true, project: rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function updateProject(req, res) {
  try {
    const { project_id } = req.params;
    const { project_name, project_description, deadline, status } = req.body;
    const [result] = await db.query(
      `UPDATE projects SET project_name = COALESCE(?, project_name),
        project_description = COALESCE(?, project_description),
        deadline = COALESCE(?, deadline),
        status = COALESCE(?, status)
       WHERE project_id = ? AND teacher_id = ?`,
      [project_name, project_description, deadline, status, project_id, req.user.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });
    return res.json({ success: true, message: 'Project updated.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function deleteProject(req, res) {
  try {
    const { project_id } = req.params;
    const [result] = await db.query('DELETE FROM projects WHERE project_id = ? AND teacher_id = ?', [
      project_id,
      req.user.id,
    ]);
    if (result.affectedRows === 0) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });
    return res.json({ success: true, message: 'Project deleted.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

// ---------- GUIDELINES ----------

async function upsertGuidelines(req, res) {
  try {
    const { project_id } = req.params;
    const { guidelines } = req.body;
    const guidelines_file_url = req.file ? `/uploads/project_guidelines/${req.file.filename}` : undefined;

    const fields = [];
    const values = [];
    if (guidelines !== undefined) { fields.push('guidelines = ?'); values.push(guidelines); }
    if (guidelines_file_url !== undefined) { fields.push('guidelines_file_url = ?'); values.push(guidelines_file_url); }
    if (!fields.length) return res.status(400).json({ success: false, message: 'Nothing to update.' });

    values.push(project_id, req.user.id);
    const [result] = await db.query(
      `UPDATE projects SET ${fields.join(', ')} WHERE project_id = ? AND teacher_id = ?`,
      values
    );
    if (result.affectedRows === 0) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });
    return res.json({ success: true, message: 'Guidelines saved.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getGuidelines(req, res) {
  try {
    const { project_id } = req.params;
    const [rows] = await db.query(
      'SELECT guidelines, guidelines_file_url FROM projects WHERE project_id = ? AND teacher_id = ?',
      [project_id, req.user.id]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });
    return res.json({ success: true, ...rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

// ---------- STAGES ----------

async function createStage(req, res) {
  try {
    const { project_id } = req.params;
    const { stage_number, stage_name, stage_description, start_date, end_date } = req.body;
    if (!stage_name) return res.status(400).json({ success: false, message: 'stage_name is required.' });

    const [result] = await db.query(
      `INSERT INTO project_stages (project_id, stage_number, stage_name, stage_description, start_date, end_date)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [project_id, stage_number || 1, stage_name, stage_description || null, start_date || null, end_date || null]
    );

    // Auto-create pending progress rows for already-enrolled students
    await db.query(
      `INSERT INTO student_stage_progress (enrollment_id, stage_id, completion_status)
       SELECT enrollment_id, ?, 'pending' FROM student_project_enrollment WHERE project_id = ?`,
      [result.insertId, project_id]
    );

    return res.status(201).json({ success: true, stage_id: result.insertId });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getStages(req, res) {
  try {
    const { project_id } = req.params;
    const [stages] = await db.query(
      'SELECT * FROM project_stages WHERE project_id = ? ORDER BY stage_number ASC',
      [project_id]
    );
    return res.json({ success: true, stages });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function updateStage(req, res) {
  try {
    const { stage_id } = req.params;
    const { stage_name, stage_description, start_date, end_date, stage_number } = req.body;
    const [result] = await db.query(
      `UPDATE project_stages SET
        stage_name = COALESCE(?, stage_name),
        stage_description = COALESCE(?, stage_description),
        start_date = COALESCE(?, start_date),
        end_date = COALESCE(?, end_date),
        stage_number = COALESCE(?, stage_number)
       WHERE stage_id = ?`,
      [stage_name, stage_description, start_date, end_date, stage_number, stage_id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });
    return res.json({ success: true, message: 'Stage updated.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function deleteStage(req, res) {
  try {
    const { stage_id } = req.params;
    const [result] = await db.query('DELETE FROM project_stages WHERE stage_id = ?', [stage_id]);
    if (result.affectedRows === 0) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });
    return res.json({ success: true, message: 'Stage deleted.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

// ---------- ENROLLMENT ----------

async function enrollStudents(req, res) {
  try {
    const { project_id } = req.params;
    const { student_ids } = req.body; // array of student_id
    if (!Array.isArray(student_ids) || !student_ids.length) {
      return res.status(400).json({ success: false, message: 'student_ids array is required.' });
    }

    const results = [];
    for (const studentId of student_ids) {
      const [existing] = await db.query(
        'SELECT enrollment_id FROM student_project_enrollment WHERE student_id = ? AND project_id = ?',
        [studentId, project_id]
      );
      if (existing.length) { results.push({ studentId, status: 'already_enrolled' }); continue; }

      const [enrollResult] = await db.query(
        'INSERT INTO student_project_enrollment (student_id, project_id) VALUES (?, ?)',
        [studentId, project_id]
      );
      const enrollmentId = enrollResult.insertId;

      const [stages] = await db.query('SELECT stage_id FROM project_stages WHERE project_id = ?', [project_id]);
      for (const stage of stages) {
        await db.query(
          'INSERT INTO student_stage_progress (enrollment_id, stage_id, completion_status) VALUES (?, ?, "pending")',
          [enrollmentId, stage.stage_id]
        );
      }
      results.push({ studentId, status: 'enrolled', enrollmentId });
    }

    return res.status(201).json({ success: true, results });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getEnrolledStudents(req, res) {
  try {
    const { project_id } = req.params;
    const [students] = await db.query(
      `SELECT e.enrollment_id, e.status AS enrollment_status, s.student_id, s.student_name, s.roll_number, s.email,
        (SELECT COUNT(*) FROM student_stage_progress sp WHERE sp.enrollment_id = e.enrollment_id AND sp.completion_status = 'completed') AS stages_completed,
        (SELECT COUNT(*) FROM project_stages ps WHERE ps.project_id = e.project_id) AS total_stages
       FROM student_project_enrollment e
       JOIN students s ON s.student_id = e.student_id
       WHERE e.project_id = ?`,
      [project_id]
    );
    return res.json({ success: true, students });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getStudentProgressDetail(req, res) {
  try {
    const { project_id, student_id } = req.params;
    const [[enrollment]] = await db.query(
      'SELECT * FROM student_project_enrollment WHERE project_id = ? AND student_id = ?',
      [project_id, student_id]
    );
    if (!enrollment) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });

    const [stageProgress] = await db.query(
      `SELECT sp.*, ps.stage_name, ps.stage_number
       FROM student_stage_progress sp
       JOIN project_stages ps ON ps.stage_id = sp.stage_id
       WHERE sp.enrollment_id = ? ORDER BY ps.stage_number`,
      [enrollment.enrollment_id]
    );

    const [submissions] = await db.query(
      'SELECT * FROM document_submissions WHERE enrollment_id = ? ORDER BY submission_date DESC',
      [enrollment.enrollment_id]
    );

    return res.json({ success: true, enrollment, stageProgress, submissions });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function removeStudent(req, res) {
  try {
    const { project_id, student_id } = req.params;
    const [result] = await db.query(
      'DELETE FROM student_project_enrollment WHERE project_id = ? AND student_id = ?',
      [project_id, student_id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });
    return res.json({ success: true, message: 'Student removed from project.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

// ---------- DOCUMENT REVIEW ----------

async function getProjectSubmissions(req, res) {
  try {
    const { project_id } = req.params;
    const { document_type, student_id, status } = req.query;

    let sql = `SELECT ds.*, s.student_name, s.roll_number
      FROM document_submissions ds
      JOIN student_project_enrollment e ON e.enrollment_id = ds.enrollment_id
      JOIN students s ON s.student_id = e.student_id
      WHERE e.project_id = ?`;
    const params = [project_id];

    if (document_type) { sql += ' AND ds.document_type = ?'; params.push(document_type); }
    if (student_id) { sql += ' AND s.student_id = ?'; params.push(student_id); }
    if (status) { sql += ' AND ds.teacher_review_status = ?'; params.push(status); }

    sql += ' ORDER BY ds.submission_date DESC';
    const [submissions] = await db.query(sql, params);
    return res.json({ success: true, submissions });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getSubmissionDetail(req, res) {
  try {
    const { submission_id } = req.params;
    const [[submission]] = await db.query(
      `SELECT ds.*, s.student_name, s.roll_number FROM document_submissions ds
       JOIN student_project_enrollment e ON e.enrollment_id = ds.enrollment_id
       JOIN students s ON s.student_id = e.student_id
       WHERE ds.submission_id = ?`,
      [submission_id]
    );
    if (!submission) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });

    const [versions] = await db.query(
      `SELECT * FROM document_submissions ds2
       WHERE ds2.enrollment_id = ? AND ds2.document_type = ?
       ORDER BY ds2.version_number DESC`,
      [submission.enrollment_id, submission.document_type]
    );

    return res.json({ success: true, submission, versions });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function reviewSubmission(req, res) {
  try {
    const { submission_id } = req.params;
    const { status, feedback_comment, suggested_correction } = req.body; // status: approved | reverted_for_correction

    await db.query(
      'UPDATE document_submissions SET teacher_review_status = ?, teacher_comments = ? WHERE submission_id = ?',
      [status, feedback_comment || null, submission_id]
    );

    await db.query(
      `INSERT INTO document_feedback (submission_id, teacher_id, feedback_comment, suggested_correction)
       VALUES (?, ?, ?, ?)`,
      [submission_id, req.user.id, feedback_comment || null, suggested_correction || null]
    );

    return res.json({ success: true, message: 'Feedback submitted.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function updateSubmissionStatus(req, res) {
  try {
    const { submission_id } = req.params;
    const { status } = req.body;
    const [result] = await db.query(
      'UPDATE document_submissions SET teacher_review_status = ? WHERE submission_id = ?',
      [status, submission_id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });
    return res.json({ success: true, message: 'Status updated.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getPendingDocuments(req, res) {
  try {
    const { project_id } = req.params;
    const [pending] = await db.query(
      `SELECT s.student_id, s.student_name, s.roll_number,
        GROUP_CONCAT(DISTINCT dt.document_type) AS missing_types
       FROM student_project_enrollment e
       JOIN students s ON s.student_id = e.student_id
       CROSS JOIN (SELECT 'permission_letter' AS document_type UNION SELECT 'completion_letter' UNION SELECT 'survey' UNION SELECT 'photos' UNION SELECT 'report') dt
       LEFT JOIN document_submissions ds ON ds.enrollment_id = e.enrollment_id AND ds.document_type = dt.document_type AND ds.is_latest = TRUE
       WHERE e.project_id = ? AND ds.submission_id IS NULL
       GROUP BY s.student_id, s.student_name, s.roll_number`,
      [project_id]
    );
    return res.json({ success: true, pending });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

// ---------- STUDENT PROGRESS / STAGE COMPLETION ----------

async function getProjectProgressReport(req, res) {
  try {
    const { project_id } = req.params;
    const [rows] = await db.query(
      `SELECT s.student_id, s.student_name, s.roll_number,
        COUNT(DISTINCT CASE WHEN sp.completion_status = 'completed' THEN sp.stage_id END) AS stages_completed,
        (SELECT COUNT(*) FROM project_stages WHERE project_id = ?) AS total_stages,
        (SELECT COUNT(*) FROM document_submissions ds WHERE ds.enrollment_id = e.enrollment_id AND ds.teacher_review_status = 'pending') AS pending_docs,
        MAX(ds2.submission_date) AS last_submission_date
       FROM student_project_enrollment e
       JOIN students s ON s.student_id = e.student_id
       LEFT JOIN student_stage_progress sp ON sp.enrollment_id = e.enrollment_id
       LEFT JOIN document_submissions ds2 ON ds2.enrollment_id = e.enrollment_id
       WHERE e.project_id = ?
       GROUP BY s.student_id, s.student_name, s.roll_number, e.enrollment_id`,
      [project_id, project_id]
    );
    return res.json({ success: true, progress: rows });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getStudentStages(req, res) {
  try {
    const { project_id, student_id } = req.params;
    const [[enrollment]] = await db.query(
      'SELECT enrollment_id FROM student_project_enrollment WHERE project_id = ? AND student_id = ?',
      [project_id, student_id]
    );
    if (!enrollment) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });

    const [stages] = await db.query(
      `SELECT ps.stage_id, ps.stage_name, ps.stage_number, sp.completion_status, sp.teacher_feedback, sp.completion_date
       FROM project_stages ps
       LEFT JOIN student_stage_progress sp ON sp.stage_id = ps.stage_id AND sp.enrollment_id = ?
       WHERE ps.project_id = ? ORDER BY ps.stage_number`,
      [enrollment.enrollment_id, project_id]
    );
    return res.json({ success: true, stages });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getStageCompletionList(req, res) {
  try {
    const { project_id, stage_id } = req.params;
    const [students] = await db.query(
      `SELECT s.student_id, s.student_name, s.roll_number, sp.completion_status, sp.teacher_feedback
       FROM student_stage_progress sp
       JOIN student_project_enrollment e ON e.enrollment_id = sp.enrollment_id
       JOIN students s ON s.student_id = e.student_id
       WHERE e.project_id = ? AND sp.stage_id = ?`,
      [project_id, stage_id]
    );
    return res.json({ success: true, students });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function markStageCompletion(req, res) {
  try {
    const { project_id, stage_id } = req.params;
    const { student_id, completion_status, teacher_feedback } = req.body;

    const [[enrollment]] = await db.query(
      'SELECT enrollment_id FROM student_project_enrollment WHERE project_id = ? AND student_id = ?',
      [project_id, student_id]
    );
    if (!enrollment) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });

    await db.query(
      `UPDATE student_stage_progress SET completion_status = ?, teacher_feedback = COALESCE(?, teacher_feedback),
        completion_date = IF(? = 'completed', CURDATE(), completion_date)
       WHERE enrollment_id = ? AND stage_id = ?`,
      [completion_status, teacher_feedback, completion_status, enrollment.enrollment_id, stage_id]
    );

    return res.json({ success: true, message: 'Stage completion updated.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

// ---------- DASHBOARD / ANALYTICS ----------

async function getDashboard(req, res) {
  try {
    const teacherId = req.user.id;
    const [[{ total_projects }]] = await db.query(
      'SELECT COUNT(*) AS total_projects FROM projects WHERE teacher_id = ?',
      [teacherId]
    );
    const [[{ active_students }]] = await db.query(
      `SELECT COUNT(DISTINCT e.student_id) AS active_students
       FROM student_project_enrollment e JOIN projects p ON p.project_id = e.project_id
       WHERE p.teacher_id = ? AND e.status = 'active'`,
      [teacherId]
    );
    const [[{ pending_reviews }]] = await db.query(
      `SELECT COUNT(*) AS pending_reviews
       FROM document_submissions ds
       JOIN student_project_enrollment e ON e.enrollment_id = ds.enrollment_id
       JOIN projects p ON p.project_id = e.project_id
       WHERE p.teacher_id = ? AND ds.teacher_review_status = 'pending'`,
      [teacherId]
    );
    const [[{ approved_documents }]] = await db.query(
      `SELECT COUNT(*) AS approved_documents
       FROM document_submissions ds
       JOIN student_project_enrollment e ON e.enrollment_id = ds.enrollment_id
       JOIN projects p ON p.project_id = e.project_id
       WHERE p.teacher_id = ? AND ds.teacher_review_status = 'approved'`,
      [teacherId]
    );
    const [recentActivity] = await db.query(
      `SELECT ds.submission_id, ds.document_type, ds.submission_date, ds.teacher_review_status,
        s.student_name, p.project_name
       FROM document_submissions ds
       JOIN student_project_enrollment e ON e.enrollment_id = ds.enrollment_id
       JOIN students s ON s.student_id = e.student_id
       JOIN projects p ON p.project_id = e.project_id
       WHERE p.teacher_id = ?
       ORDER BY ds.submission_date DESC LIMIT 10`,
      [teacherId]
    );

    return res.json({
      success: true,
      stats: { total_projects, active_students, pending_reviews, approved_documents },
      recentActivity,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getProjectAnalytics(req, res) {
  try {
    const { project_id } = req.params;

    const [[stageStats]] = await db.query(
      `SELECT
        COUNT(*) AS total_stage_progress_rows,
        SUM(CASE WHEN completion_status = 'completed' THEN 1 ELSE 0 END) AS completed_rows
       FROM student_stage_progress sp
       JOIN project_stages ps ON ps.stage_id = sp.stage_id
       WHERE ps.project_id = ?`,
      [project_id]
    );

    const [[docStats]] = await db.query(
      `SELECT COUNT(*) AS total_docs,
        SUM(CASE WHEN teacher_review_status = 'approved' THEN 1 ELSE 0 END) AS approved_docs
       FROM document_submissions ds
       JOIN student_project_enrollment e ON e.enrollment_id = ds.enrollment_id
       WHERE e.project_id = ?`,
      [project_id]
    );

    const completionPct = stageStats.total_stage_progress_rows
      ? Math.round((stageStats.completed_rows / stageStats.total_stage_progress_rows) * 100)
      : 0;
    const submissionPct = docStats.total_docs
      ? Math.round((docStats.approved_docs / docStats.total_docs) * 100)
      : 0;

    return res.json({
      success: true,
      analytics: {
        completion_percentage: completionPct,
        document_approval_percentage: submissionPct,
        ...stageStats,
        ...docStats,
      },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

// ---------- ANNOUNCEMENTS ----------

async function createAnnouncement(req, res) {
  try {
    const { project_id } = req.params;
    const { announcement_text, expiry_date } = req.body;
    const [result] = await db.query(
      'INSERT INTO project_announcements (project_id, teacher_id, announcement_text, expiry_date) VALUES (?, ?, ?, ?)',
      [project_id, req.user.id, announcement_text, expiry_date || null]
    );
    return res.status(201).json({ success: true, announcement_id: result.insertId });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getAnnouncements(req, res) {
  try {
    const { project_id } = req.params;
    const [announcements] = await db.query(
      'SELECT * FROM project_announcements WHERE project_id = ? ORDER BY created_date DESC',
      [project_id]
    );
    return res.json({ success: true, announcements });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function updateAnnouncement(req, res) {
  try {
    const { announcement_id } = req.params;
    const { announcement_text, expiry_date } = req.body;
    await db.query(
      'UPDATE project_announcements SET announcement_text = COALESCE(?, announcement_text), expiry_date = COALESCE(?, expiry_date) WHERE announcement_id = ? AND teacher_id = ?',
      [announcement_text, expiry_date, announcement_id, req.user.id]
    );
    return res.json({ success: true, message: 'Announcement updated.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function deleteAnnouncement(req, res) {
  try {
    const { announcement_id } = req.params;
    await db.query('DELETE FROM project_announcements WHERE announcement_id = ? AND teacher_id = ?', [
      announcement_id,
      req.user.id,
    ]);
    return res.json({ success: true, message: 'Announcement deleted.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

module.exports = {
  createProject, getProjects, getProjectById, updateProject, deleteProject,
  upsertGuidelines, getGuidelines,
  createStage, getStages, updateStage, deleteStage,
  enrollStudents, getEnrolledStudents, getStudentProgressDetail, removeStudent,
  getProjectSubmissions, getSubmissionDetail, reviewSubmission, updateSubmissionStatus, getPendingDocuments,
  getProjectProgressReport, getStudentStages, getStageCompletionList, markStageCompletion,
  getDashboard, getProjectAnalytics,
  createAnnouncement, getAnnouncements, updateAnnouncement, deleteAnnouncement,
};
