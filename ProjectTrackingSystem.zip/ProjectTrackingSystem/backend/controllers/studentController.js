const db = require('../config/db');
const { MESSAGES, DOCUMENT_TYPES } = require('../utils/constants');

async function getEnrollmentOrFail(studentId, projectId, res) {
  const [[enrollment]] = await db.query(
    'SELECT * FROM student_project_enrollment WHERE student_id = ? AND project_id = ?',
    [studentId, projectId]
  );
  if (!enrollment) {
    res.status(404).json({ success: false, message: 'You are not enrolled in this project.' });
    return null;
  }
  return enrollment;
}

// ---------- PROJECT ACCESS ----------

async function getMyProjects(req, res) {
  try {
    const [projects] = await db.query(
      `SELECT p.*, e.enrollment_id, e.status AS enrollment_status,
        t.full_name AS teacher_name,
        (SELECT COUNT(*) FROM student_stage_progress sp WHERE sp.enrollment_id = e.enrollment_id AND sp.completion_status = 'completed') AS stages_completed,
        (SELECT COUNT(*) FROM project_stages ps WHERE ps.project_id = p.project_id) AS total_stages
       FROM student_project_enrollment e
       JOIN projects p ON p.project_id = e.project_id
       JOIN teachers t ON t.teacher_id = p.teacher_id
       WHERE e.student_id = ?`,
      [req.user.id]
    );
    return res.json({ success: true, projects });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getProjectDetails(req, res) {
  try {
    const { project_id } = req.params;
    const enrollment = await getEnrollmentOrFail(req.user.id, project_id, res);
    if (!enrollment) return;

    const [[project]] = await db.query(
      `SELECT p.*, t.full_name AS teacher_name, t.email AS teacher_email
       FROM projects p JOIN teachers t ON t.teacher_id = p.teacher_id WHERE p.project_id = ?`,
      [project_id]
    );
    return res.json({ success: true, project });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getProjectStages(req, res) {
  try {
    const { project_id } = req.params;
    const enrollment = await getEnrollmentOrFail(req.user.id, project_id, res);
    if (!enrollment) return;

    const [stages] = await db.query(
      `SELECT ps.*, sp.completion_status, sp.teacher_feedback, sp.completion_date
       FROM project_stages ps
       LEFT JOIN student_stage_progress sp ON sp.stage_id = ps.stage_id AND sp.enrollment_id = ?
       WHERE ps.project_id = ? ORDER BY ps.stage_number`,
      [enrollment.enrollment_id, project_id]
    );
    return res.json({ success: true, stages });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getGuidelines(req, res) {
  try {
    const { project_id } = req.params;
    const enrollment = await getEnrollmentOrFail(req.user.id, project_id, res);
    if (!enrollment) return;

    const [[project]] = await db.query(
      'SELECT guidelines, guidelines_file_url FROM projects WHERE project_id = ?',
      [project_id]
    );
    return res.json({ success: true, ...project });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getAnnouncements(req, res) {
  try {
    const { project_id } = req.params;
    const enrollment = await getEnrollmentOrFail(req.user.id, project_id, res);
    if (!enrollment) return;

    const [announcements] = await db.query(
      `SELECT * FROM project_announcements WHERE project_id = ?
       AND (expiry_date IS NULL OR expiry_date >= CURDATE())
       ORDER BY created_date DESC`,
      [project_id]
    );
    return res.json({ success: true, announcements });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

// ---------- PROGRESS TRACKING ----------

async function getMyProgress(req, res) {
  try {
    const { project_id } = req.params;
    const enrollment = await getEnrollmentOrFail(req.user.id, project_id, res);
    if (!enrollment) return;

    const [[{ total_stages }]] = await db.query(
      'SELECT COUNT(*) AS total_stages FROM project_stages WHERE project_id = ?',
      [project_id]
    );
    const [[{ completed_stages }]] = await db.query(
      `SELECT COUNT(*) AS completed_stages FROM student_stage_progress
       WHERE enrollment_id = ? AND completion_status = 'completed'`,
      [enrollment.enrollment_id]
    );

    return res.json({
      success: true,
      total_stages,
      completed_stages,
      completion_percentage: total_stages ? Math.round((completed_stages / total_stages) * 100) : 0,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getMyStages(req, res) {
  return getProjectStages(req, res); // same underlying data, student-facing alias
}

async function getStageStatus(req, res) {
  try {
    const { project_id, stage_id } = req.params;
    const enrollment = await getEnrollmentOrFail(req.user.id, project_id, res);
    if (!enrollment) return;

    const [[status]] = await db.query(
      'SELECT * FROM student_stage_progress WHERE enrollment_id = ? AND stage_id = ?',
      [enrollment.enrollment_id, stage_id]
    );
    return res.json({ success: true, status });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

// ---------- DOCUMENT SUBMISSION ----------

async function submitDocument(req, res) {
  try {
    const { project_id } = req.params;
    const { document_type, stage_id } = req.body;
    const enrollment = await getEnrollmentOrFail(req.user.id, project_id, res);
    if (!enrollment) return;

    if (!DOCUMENT_TYPES.includes(document_type)) {
      return res.status(400).json({ success: false, message: 'Invalid document_type.' });
    }
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'A file is required.' });
    }

    const [[latest]] = await db.query(
      `SELECT MAX(version_number) AS max_version FROM document_submissions
       WHERE enrollment_id = ? AND document_type = ?`,
      [enrollment.enrollment_id, document_type]
    );
    const nextVersion = (latest.max_version || 0) + 1;

    await db.query(
      `UPDATE document_submissions SET is_latest = FALSE
       WHERE enrollment_id = ? AND document_type = ?`,
      [enrollment.enrollment_id, document_type]
    );

    const fileUrl = `/uploads/student_documents/student_${req.user.id}/project_${project_id}/${req.file.filename}`;

    const [result] = await db.query(
      `INSERT INTO document_submissions
        (enrollment_id, stage_id, document_type, file_url, original_filename, version_number, is_latest)
       VALUES (?, ?, ?, ?, ?, ?, TRUE)`,
      [enrollment.enrollment_id, stage_id || null, document_type, fileUrl, req.file.originalname, nextVersion]
    );

    return res.status(201).json({ success: true, submission_id: result.insertId, version: nextVersion });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getMySubmissions(req, res) {
  try {
    const { project_id } = req.params;
    const enrollment = await getEnrollmentOrFail(req.user.id, project_id, res);
    if (!enrollment) return;

    const [submissions] = await db.query(
      'SELECT * FROM document_submissions WHERE enrollment_id = ? ORDER BY submission_date DESC',
      [enrollment.enrollment_id]
    );
    return res.json({ success: true, submissions });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getSubmissionById(req, res) {
  try {
    const { submission_id } = req.params;
    const [[submission]] = await db.query(
      `SELECT ds.* FROM document_submissions ds
       JOIN student_project_enrollment e ON e.enrollment_id = ds.enrollment_id
       WHERE ds.submission_id = ? AND e.student_id = ?`,
      [submission_id, req.user.id]
    );
    if (!submission) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });
    return res.json({ success: true, submission });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getPendingDocuments(req, res) {
  try {
    const { project_id } = req.params;
    const enrollment = await getEnrollmentOrFail(req.user.id, project_id, res);
    if (!enrollment) return;

    const [submitted] = await db.query(
      `SELECT DISTINCT document_type FROM document_submissions WHERE enrollment_id = ? AND is_latest = TRUE`,
      [enrollment.enrollment_id]
    );
    const submittedTypes = submitted.map((s) => s.document_type);
    const pending = DOCUMENT_TYPES.filter((t) => t !== 'other' && !submittedTypes.includes(t));

    return res.json({ success: true, pending });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

// ---------- FEEDBACK & REVISION ----------

async function getSubmissionFeedback(req, res) {
  try {
    const { submission_id } = req.params;
    const [[submission]] = await db.query(
      `SELECT ds.submission_id FROM document_submissions ds
       JOIN student_project_enrollment e ON e.enrollment_id = ds.enrollment_id
       WHERE ds.submission_id = ? AND e.student_id = ?`,
      [submission_id, req.user.id]
    );
    if (!submission) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });

    const [feedback] = await db.query(
      'SELECT * FROM document_feedback WHERE submission_id = ? ORDER BY feedback_date DESC',
      [submission_id]
    );
    return res.json({ success: true, feedback });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function resubmitDocument(req, res) {
  try {
    const { submission_id } = req.params;
    const [[original]] = await db.query(
      `SELECT ds.* FROM document_submissions ds
       JOIN student_project_enrollment e ON e.enrollment_id = ds.enrollment_id
       WHERE ds.submission_id = ? AND e.student_id = ?`,
      [submission_id, req.user.id]
    );
    if (!original) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });
    if (!req.file) return res.status(400).json({ success: false, message: 'A file is required.' });

    await db.query(
      'UPDATE document_submissions SET is_latest = FALSE WHERE enrollment_id = ? AND document_type = ?',
      [original.enrollment_id, original.document_type]
    );

    const nextVersion = original.version_number + 1;
    const fileUrl = `/uploads/student_documents/student_${req.user.id}/project_${req.params.project_id || 'x'}/${req.file.filename}`;

    const [result] = await db.query(
      `INSERT INTO document_submissions
        (enrollment_id, stage_id, document_type, file_url, original_filename, version_number, is_latest)
       VALUES (?, ?, ?, ?, ?, ?, TRUE)`,
      [original.enrollment_id, original.stage_id, original.document_type, fileUrl, req.file.originalname, nextVersion]
    );

    return res.status(201).json({ success: true, submission_id: result.insertId, version: nextVersion });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getVersionHistory(req, res) {
  try {
    const { submission_id } = req.params;
    const [[submission]] = await db.query(
      `SELECT ds.enrollment_id, ds.document_type FROM document_submissions ds
       JOIN student_project_enrollment e ON e.enrollment_id = ds.enrollment_id
       WHERE ds.submission_id = ? AND e.student_id = ?`,
      [submission_id, req.user.id]
    );
    if (!submission) return res.status(404).json({ success: false, message: MESSAGES.NOT_FOUND });

    const [versions] = await db.query(
      `SELECT * FROM document_submissions WHERE enrollment_id = ? AND document_type = ? ORDER BY version_number DESC`,
      [submission.enrollment_id, submission.document_type]
    );
    return res.json({ success: true, versions });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

// ---------- DASHBOARD ----------

async function getDashboard(req, res) {
  try {
    const studentId = req.user.id;
    const [[{ total_projects }]] = await db.query(
      'SELECT COUNT(*) AS total_projects FROM student_project_enrollment WHERE student_id = ?',
      [studentId]
    );
    const [[{ pending_submissions }]] = await db.query(
      `SELECT COUNT(*) AS pending_submissions FROM document_submissions ds
       JOIN student_project_enrollment e ON e.enrollment_id = ds.enrollment_id
       WHERE e.student_id = ? AND ds.teacher_review_status = 'reverted_for_correction'`,
      [studentId]
    );
    const [[{ completed_stages }]] = await db.query(
      `SELECT COUNT(*) AS completed_stages FROM student_stage_progress sp
       JOIN student_project_enrollment e ON e.enrollment_id = sp.enrollment_id
       WHERE e.student_id = ? AND sp.completion_status = 'completed'`,
      [studentId]
    );
    const [upcomingDeadlines] = await db.query(
      `SELECT p.project_id, p.project_name, p.deadline FROM projects p
       JOIN student_project_enrollment e ON e.project_id = p.project_id
       WHERE e.student_id = ? AND p.deadline >= CURDATE() ORDER BY p.deadline ASC LIMIT 5`,
      [studentId]
    );

    return res.json({
      success: true,
      stats: { total_projects, pending_submissions, completed_stages },
      upcomingDeadlines,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

async function getDeadlineStatus(req, res) {
  try {
    const { project_id } = req.params;
    const enrollment = await getEnrollmentOrFail(req.user.id, project_id, res);
    if (!enrollment) return;

    const [[project]] = await db.query('SELECT deadline FROM projects WHERE project_id = ?', [project_id]);
    const [[{ total_stages }]] = await db.query(
      'SELECT COUNT(*) AS total_stages FROM project_stages WHERE project_id = ?',
      [project_id]
    );
    const [[{ completed_stages }]] = await db.query(
      `SELECT COUNT(*) AS completed_stages FROM student_stage_progress
       WHERE enrollment_id = ? AND completion_status = 'completed'`,
      [enrollment.enrollment_id]
    );

    const daysRemaining = project.deadline
      ? Math.ceil((new Date(project.deadline) - new Date()) / (1000 * 60 * 60 * 24))
      : null;
    const expectedProgress = total_stages ? completed_stages / total_stages : 0;

    return res.json({
      success: true,
      deadline: project.deadline,
      daysRemaining,
      onTrack: expectedProgress >= 0.4 || daysRemaining === null || daysRemaining > 14,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: MESSAGES.SERVER_ERROR });
  }
}

module.exports = {
  getMyProjects, getProjectDetails, getProjectStages, getGuidelines, getAnnouncements,
  getMyProgress, getMyStages, getStageStatus,
  submitDocument, getMySubmissions, getSubmissionById, getPendingDocuments,
  getSubmissionFeedback, resubmitDocument, getVersionHistory,
  getDashboard, getDeadlineStatus,
};
