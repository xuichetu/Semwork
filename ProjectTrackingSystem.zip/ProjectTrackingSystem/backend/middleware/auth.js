const { verifyAccessToken } = require('../utils/jwt');
const { MESSAGES } = require('../utils/constants');

function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, message: MESSAGES.UNAUTHORIZED });
  }
  const token = authHeader.split(' ')[1];
  try {
    const decoded = verifyAccessToken(token);
    req.user = decoded; // { id, role, name, ... }
    next();
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Session expired. Please log in again.' });
  }
}

function requireRole(role) {
  return (req, res, next) => {
    if (!req.user || req.user.role !== role) {
      return res.status(403).json({ success: false, message: MESSAGES.FORBIDDEN });
    }
    next();
  };
}

module.exports = { authenticate, requireRole };
