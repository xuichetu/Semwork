const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { ALLOWED_MIME_TYPES, MAX_FILE_SIZE_MB } = require('../utils/constants');

// Builds uploads/student_documents/student_<id>/project_<id>/
function buildDestination(req) {
  const studentId = req.user?.id || 'unknown';
  const projectId = req.params.project_id || req.body.project_id || 'general';
  const dest = path.join(
    __dirname,
    '..',
    'uploads',
    'student_documents',
    `student_${studentId}`,
    `project_${projectId}`
  );
  fs.mkdirSync(dest, { recursive: true });
  return dest;
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    try {
      cb(null, buildDestination(req));
    } catch (err) {
      cb(err);
    }
  },
  filename: (req, file, cb) => {
    const docType = req.body.document_type || 'document';
    const timestamp = Date.now();
    const ext = path.extname(file.originalname);
    cb(null, `${docType}_${timestamp}${ext}`);
  },
});

function fileFilter(req, file, cb) {
  if (ALLOWED_MIME_TYPES.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Only PDF, DOCX, and images are allowed.'));
  }
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: MAX_FILE_SIZE_MB * 1024 * 1024 },
});

// Separate storage for teacher guideline uploads
const guidelinesStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dest = path.join(__dirname, '..', 'uploads', 'project_guidelines');
    fs.mkdirSync(dest, { recursive: true });
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const projectId = req.params.project_id || 'general';
    const ext = path.extname(file.originalname);
    cb(null, `project_${projectId}_guidelines_${Date.now()}${ext}`);
  },
});

const uploadGuidelines = multer({
  storage: guidelinesStorage,
  fileFilter,
  limits: { fileSize: MAX_FILE_SIZE_MB * 1024 * 1024 },
});

module.exports = { upload, uploadGuidelines };
