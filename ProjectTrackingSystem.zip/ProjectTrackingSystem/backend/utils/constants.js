module.exports = {
  ROLES: {
    TEACHER: 'teacher',
    STUDENT: 'student',
  },
  DOCUMENT_TYPES: ['permission_letter', 'completion_letter', 'survey', 'photos', 'report', 'other'],
  REVIEW_STATUS: {
    PENDING: 'pending',
    APPROVED: 'approved',
    REVERTED: 'reverted_for_correction',
  },
  STAGE_STATUS: {
    PENDING: 'pending',
    UNDER_REVIEW: 'under_review',
    COMPLETED: 'completed',
  },
  MESSAGES: {
    UNAUTHORIZED: 'Unauthorized. Please log in again.',
    FORBIDDEN: 'You do not have permission to perform this action.',
    NOT_FOUND: 'Requested resource not found.',
    SERVER_ERROR: 'Something went wrong on the server.',
    INVALID_CREDENTIALS: 'Invalid login credentials.',
  },
  ALLOWED_MIME_TYPES: [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'image/jpeg',
    'image/png',
    'image/jpg',
  ],
  MAX_FILE_SIZE_MB: 10,
};
