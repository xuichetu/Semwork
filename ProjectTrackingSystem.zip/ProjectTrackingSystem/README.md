# Project Tracking System

A full-stack academic project tracking system with separate **Student** and **Teacher** modules — guidelines, multi-stage progress tracking, document submission with version control, teacher feedback/review, announcements, and analytics.

**Stack:** React.js (frontend) + Node.js/Express (backend) + MySQL (database), JWT auth.

---

## 1. Project Structure

```
ProjectTrackingSystem/
├── backend/       Node/Express API
├── frontend/      React app
└── database/      MySQL schema.sql + seed.sql
```

## 2. Prerequisites

- Node.js 18+ and npm
- MySQL 8+ running locally (or a remote instance)

## 3. Database Setup

```bash
mysql -u root -p < database/schema.sql
mysql -u root -p < database/seed.sql   # optional demo data
```

The seed data creates:
- **Teacher login:** unique ID `T001`, password `password123`
- **Student logins:** roll numbers `CS2024001` / `CS2024002`, password `password123`

## 4. Backend Setup

```bash
cd backend
cp .env.example .env
# edit .env with your MySQL credentials and a strong JWT secret
npm install
npm run dev      # nodemon, auto-restarts on changes
# or: npm start
```

The API runs on `http://localhost:5000` by default. Health check: `GET /api/health`.

Uploaded files are served from `http://localhost:5000/uploads/...` and stored under `backend/uploads/`.

## 5. Frontend Setup

```bash
cd frontend
cp .env.example .env
# REACT_APP_API_URL should point at your backend, e.g. http://localhost:5000/api
npm install
npm start
```

The app runs on `http://localhost:3000`.

## 6. Logging In

Go to `http://localhost:3000/login`, choose **Student** or **Teacher**, and use the seeded credentials above (or create your own rows directly in the `teachers`/`students` tables — passwords must be bcrypt hashes).

To generate a bcrypt hash for a new password:
```bash
node -e "console.log(require('bcrypt').hashSync('yourpassword', 10))"
```

## 7. What's Implemented

- JWT auth (login/logout/verify/refresh) for both roles, 30-minute access tokens with refresh flow
- Teacher: create/edit/delete projects, guidelines (text + file upload), multi-stage timelines, bulk student enrollment, progress dashboard, document review & feedback (approve / revert for correction), pending-document detection, announcements, per-project analytics
- Student: view assigned projects & guidelines, stage progress tracker, document submission with drag-free file picker (PDF/DOCX/images, 10MB limit), version history on resubmission, feedback view, announcements, dashboard with upcoming deadlines
- Document version control: every resubmission increments `version_number` and flips `is_latest`
- File storage organized under `backend/uploads/{project_guidelines, student_documents/student_<id>/project_<id>}`

## 8. Known Gaps / Next Steps

This is a strong working foundation, not a finished enterprise product. Before production use, add:

- A `GET /api/teacher/students` (search/list) endpoint + a proper student picker UI — enrollment currently requires knowing a numeric `student_id`
- Change-password endpoints for both roles (UI stub exists on the Profile pages)
- Bulk reminder emails / Excel export for the pending-documents report
- Server-side pagination on submission and progress tables for large classes
- Refresh-token rotation/blacklisting and rate limiting on `/api/auth/login`
- Automated tests (none included)

## 9. Security Notes

- Passwords are hashed with bcrypt; never store plaintext.
- Replace the placeholder `JWT_SECRET` / `JWT_REFRESH_SECRET` in `.env` with long random values before deploying.
- File uploads are restricted by MIME type and a 10MB size cap; review `backend/middleware/upload.js` if you need to change allowed types.
