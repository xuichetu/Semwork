import React from 'react';

const LABELS = {
  pending: 'Pending',
  approved: 'Approved',
  reverted_for_correction: 'Revision Requested',
  active: 'Active',
  completed: 'Completed',
  under_review: 'Under Review',
  dropped: 'Dropped',
  archived: 'Archived',
};

const CLASS_MAP = {
  pending: 'badge-pending',
  approved: 'badge-approved',
  reverted_for_correction: 'badge-reverted',
  active: 'badge-active',
  completed: 'badge-completed',
  under_review: 'badge-pending',
  dropped: 'badge-reverted',
  archived: 'badge-pending',
};

export default function StatusBadge({ status }) {
  if (!status) return null;
  return <span className={`badge ${CLASS_MAP[status] || 'badge-pending'}`}>{LABELS[status] || status}</span>;
}
