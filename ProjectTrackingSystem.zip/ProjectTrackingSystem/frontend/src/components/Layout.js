import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const studentLinks = [
  { to: '/student/dashboard', label: 'Dashboard' },
  { to: '/student/projects', label: 'My Projects' },
  { to: '/student/profile', label: 'Profile' },
];

const teacherLinks = [
  { to: '/teacher/dashboard', label: 'Dashboard' },
  { to: '/teacher/projects', label: 'Projects' },
  { to: '/teacher/reviews', label: 'Document Review' },
  { to: '/teacher/profile', label: 'Profile' },
];

export default function Layout({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const links = user?.role === 'teacher' ? teacherLinks : studentLinks;

  function handleLogout() {
    logout();
    navigate('/login');
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">Project<span>Track</span></div>
        <nav>
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} className={({ isActive }) => (isActive ? 'active' : '')}>
              {l.label}
            </NavLink>
          ))}
        </nav>
        <button className="logout-btn" onClick={handleLogout}>Log out</button>
      </aside>
      <main className="main-content">{children}</main>
    </div>
  );
}
