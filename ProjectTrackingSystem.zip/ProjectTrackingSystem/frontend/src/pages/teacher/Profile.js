import React from 'react';
import Layout from '../../components/Layout';
import { useAuth } from '../../context/AuthContext';

export default function TeacherProfile() {
  const { user } = useAuth();
  return (
    <Layout>
      <div className="page-header">
        <div>
          <h1>My Profile</h1>
          <p>Your teacher account details.</p>
        </div>
      </div>
      <div className="card">
        <p><strong>Name:</strong> {user?.full_name}</p>
        <p><strong>Unique ID:</strong> {user?.unique_id}</p>
        <p><strong>Email:</strong> {user?.email}</p>
        <p><strong>Department:</strong> {user?.department}</p>
        <p><strong>Phone:</strong> {user?.phone_number}</p>
      </div>
    </Layout>
  );
}
