import React, { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import StatusBadge from '../../components/StatusBadge';
import { useAuth } from '../../context/AuthContext';

export default function TeacherDashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/teacher/dashboard').then((res) => setData(res.data)).finally(() => setLoading(false));
  }, []);

  return (
    <Layout>
      <div className="page-header">
        <div>
          <h1>Welcome, {user?.full_name || 'Teacher'}</h1>
          <p>Overview of your projects and pending reviews.</p>
        </div>
      </div>

      {loading ? (
        <div className="loading">Loading dashboard...</div>
      ) : (
        <>
          <div className="grid grid-4" style={{ marginBottom: 24 }}>
            <div className="card stat-card">
              <div className="value">{data?.stats?.total_projects ?? 0}</div>
              <div className="label">Total Projects</div>
            </div>
            <div className="card stat-card">
              <div className="value">{data?.stats?.active_students ?? 0}</div>
              <div className="label">Active Students</div>
            </div>
            <div className="card stat-card">
              <div className="value">{data?.stats?.pending_reviews ?? 0}</div>
              <div className="label">Pending Reviews</div>
            </div>
            <div className="card stat-card">
              <div className="value">{data?.stats?.approved_documents ?? 0}</div>
              <div className="label">Approved Documents</div>
            </div>
          </div>

          <div className="card">
            <h3 style={{ marginTop: 0 }}>Recent Activity</h3>
            {data?.recentActivity?.length ? (
              <table>
                <thead><tr><th>Student</th><th>Project</th><th>Document</th><th>Status</th><th>Date</th></tr></thead>
                <tbody>
                  {data.recentActivity.map((a) => (
                    <tr key={a.submission_id}>
                      <td>{a.student_name}</td>
                      <td>{a.project_name}</td>
                      <td>{a.document_type}</td>
                      <td><StatusBadge status={a.teacher_review_status} /></td>
                      <td>{new Date(a.submission_date).toLocaleDateString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <p className="empty-state">No recent submissions.</p>
            )}
          </div>
        </>
      )}
    </Layout>
  );
}
