import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import StatusBadge from '../../components/StatusBadge';

export default function TeacherProjects() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ project_name: '', project_description: '', deadline: '', guidelines: '' });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  function loadProjects() {
    setLoading(true);
    api.get('/teacher/projects').then((res) => setProjects(res.data.projects)).finally(() => setLoading(false));
  }

  useEffect(() => { loadProjects(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await api.post('/teacher/projects', form);
      setShowModal(false);
      setForm({ project_name: '', project_description: '', deadline: '', guidelines: '' });
      loadProjects();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create project.');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id) {
    if (!window.confirm('Delete this project? This cannot be undone.')) return;
    await api.delete(`/teacher/projects/${id}`);
    loadProjects();
  }

  return (
    <Layout>
      <div className="page-header">
        <div>
          <h1>Projects</h1>
          <p>Create and manage your academic projects.</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ Create Project</button>
      </div>

      {loading ? (
        <div className="loading">Loading projects...</div>
      ) : projects.length === 0 ? (
        <div className="card empty-state">No projects yet. Create your first one to get started.</div>
      ) : (
        <div className="grid grid-2">
          {projects.map((p) => (
            <div className="card" key={p.project_id}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <h3 style={{ margin: '0 0 4px' }}>{p.project_name}</h3>
                <StatusBadge status={p.status} />
              </div>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem' }}>
                {p.enrolled_count} students enrolled &middot; Deadline:{' '}
                {p.deadline ? new Date(p.deadline).toLocaleDateString() : 'N/A'}
              </p>
              <div style={{ display: 'flex', gap: 8 }}>
                <Link className="btn btn-secondary" to={`/teacher/projects/${p.project_id}`}>Manage</Link>
                <button className="btn btn-danger" onClick={() => handleDelete(p.project_id)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-box" onClick={(e) => e.stopPropagation()}>
            <h3 style={{ marginTop: 0 }}>Create New Project</h3>
            <form onSubmit={handleCreate}>
              <div className="field">
                <label>Project Name</label>
                <input
                  value={form.project_name}
                  onChange={(e) => setForm({ ...form, project_name: e.target.value })}
                  required
                />
              </div>
              <div className="field">
                <label>Description</label>
                <textarea
                  rows={3}
                  value={form.project_description}
                  onChange={(e) => setForm({ ...form, project_description: e.target.value })}
                />
              </div>
              <div className="field">
                <label>Deadline</label>
                <input
                  type="date"
                  value={form.deadline}
                  onChange={(e) => setForm({ ...form, deadline: e.target.value })}
                />
              </div>
              <div className="field">
                <label>Guidelines (text)</label>
                <textarea
                  rows={3}
                  value={form.guidelines}
                  onChange={(e) => setForm({ ...form, guidelines: e.target.value })}
                />
              </div>
              {error && <p className="error-text">{error}</p>}
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-primary" disabled={saving}>{saving ? 'Creating...' : 'Create Project'}</button>
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
