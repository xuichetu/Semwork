import React, { useEffect, useState, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import StatusBadge from '../../components/StatusBadge';

export default function TeacherProjectManage() {
  const { project_id } = useParams();
  const [tab, setTab] = useState('guidelines');
  const [project, setProject] = useState(null);
  const [stages, setStages] = useState([]);
  const [students, setStudents] = useState([]);
  const [progress, setProgress] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [analytics, setAnalytics] = useState(null);

  const [guidelinesText, setGuidelinesText] = useState('');
  const [savingGuidelines, setSavingGuidelines] = useState(false);

  const [stageForm, setStageForm] = useState({ stage_name: '', stage_description: '', start_date: '', end_date: '', stage_number: 1 });
  const [announcementText, setAnnouncementText] = useState('');

  const loadAll = useCallback(async () => {
    const [p, s, es, pr, an] = await Promise.all([
      api.get(`/teacher/projects/${project_id}`),
      api.get(`/teacher/projects/${project_id}/stages`),
      api.get(`/teacher/projects/${project_id}/enrolled-students`),
      api.get(`/teacher/projects/${project_id}/progress-report`),
      api.get(`/teacher/projects/${project_id}/announcements`),
    ]);
    setProject(p.data.project);
    setGuidelinesText(p.data.project.guidelines || '');
    setStages(s.data.stages);
    setStudents(es.data.students);
    setProgress(pr.data.progress);
    setAnnouncements(an.data.announcements);
    api.get(`/teacher/projects/${project_id}/analytics`).then((res) => setAnalytics(res.data.analytics));
  }, [project_id]);

  useEffect(() => { loadAll(); }, [loadAll]);

  // NOTE: there's no generic "list all students" endpoint in the spec beyond enrolled ones for a project.
  // In production, add GET /api/teacher/students. For now we reuse enrolled + a manual roll number field.
  const [manualRoll, setManualRoll] = useState('');

  async function handleSaveGuidelines(e) {
    e.preventDefault();
    setSavingGuidelines(true);
    try {
      await api.put(`/teacher/projects/${project_id}/guidelines`, { guidelines: guidelinesText });
      loadAll();
    } finally {
      setSavingGuidelines(false);
    }
  }

  async function handleAddStage(e) {
    e.preventDefault();
    await api.post(`/teacher/projects/${project_id}/stages`, stageForm);
    setStageForm({ stage_name: '', stage_description: '', start_date: '', end_date: '', stage_number: stages.length + 2 });
    loadAll();
  }

  async function handleDeleteStage(stageId) {
    if (!window.confirm('Delete this stage?')) return;
    await api.delete(`/teacher/projects/${project_id}/stages/${stageId}`);
    loadAll();
  }

  async function handleEnrollByRoll(e) {
    e.preventDefault();
    // Since we don't have a students-search endpoint per spec, this looks up by trying the enrollment
    // call with a resolved ID. For a real deployment, wire this to a GET /api/teacher/students?query=
    alert('To enroll students, use the "Enroll Students" form with numeric student IDs (see README) — a searchable picker requires the GET /api/teacher/students endpoint noted in the code comments.');
  }

  async function handleRemoveStudent(studentId) {
    if (!window.confirm('Remove this student from the project?')) return;
    await api.delete(`/teacher/projects/${project_id}/student/${studentId}`);
    loadAll();
  }

  async function handlePostAnnouncement(e) {
    e.preventDefault();
    if (!announcementText.trim()) return;
    await api.post(`/teacher/projects/${project_id}/announcements`, { announcement_text: announcementText });
    setAnnouncementText('');
    loadAll();
  }

  async function handleDeleteAnnouncement(id) {
    await api.delete(`/teacher/announcements/${id}`);
    loadAll();
  }

  if (!project) return <Layout><div className="loading">Loading project...</div></Layout>;

  return (
    <Layout>
      <div className="page-header">
        <div>
          <h1>{project.project_name}</h1>
          <p>{project.enrolled_count ?? students.length} students enrolled &middot; Status: {project.status}</p>
        </div>
      </div>

      <div className="tabs">
        {['guidelines', 'stages', 'students', 'progress', 'announcements', 'analytics'].map((t) => (
          <button key={t} className={tab === t ? 'active' : ''} onClick={() => setTab(t)}>
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {tab === 'guidelines' && (
        <div className="card">
          <h3 style={{ marginTop: 0 }}>Guidelines</h3>
          <form onSubmit={handleSaveGuidelines}>
            <div className="field">
              <label>Guidelines Text (visible to enrolled students)</label>
              <textarea rows={8} value={guidelinesText} onChange={(e) => setGuidelinesText(e.target.value)} />
            </div>
            <button className="btn btn-primary" disabled={savingGuidelines}>
              {savingGuidelines ? 'Saving...' : 'Save Guidelines'}
            </button>
          </form>
        </div>
      )}

      {tab === 'stages' && (
        <div className="grid grid-2">
          <div className="card">
            <h3 style={{ marginTop: 0 }}>Add Stage</h3>
            <form onSubmit={handleAddStage}>
              <div className="field">
                <label>Stage Number</label>
                <input type="number" value={stageForm.stage_number} onChange={(e) => setStageForm({ ...stageForm, stage_number: Number(e.target.value) })} />
              </div>
              <div className="field">
                <label>Stage Name</label>
                <input value={stageForm.stage_name} onChange={(e) => setStageForm({ ...stageForm, stage_name: e.target.value })} required />
              </div>
              <div className="field">
                <label>Description</label>
                <textarea rows={2} value={stageForm.stage_description} onChange={(e) => setStageForm({ ...stageForm, stage_description: e.target.value })} />
              </div>
              <div className="grid grid-2">
                <div className="field">
                  <label>Start Date</label>
                  <input type="date" value={stageForm.start_date} onChange={(e) => setStageForm({ ...stageForm, start_date: e.target.value })} />
                </div>
                <div className="field">
                  <label>End Date</label>
                  <input type="date" value={stageForm.end_date} onChange={(e) => setStageForm({ ...stageForm, end_date: e.target.value })} />
                </div>
              </div>
              <button className="btn btn-primary">Add Stage</button>
            </form>
          </div>
          <div className="card">
            <h3 style={{ marginTop: 0 }}>Stage Timeline</h3>
            <ul className="stage-list">
              {stages.map((s) => (
                <li className="stage-item" key={s.stage_id}>
                  <div className="stage-check pending">{s.stage_number}</div>
                  <div style={{ flex: 1 }}>
                    <strong>{s.stage_name}</strong>
                    <p style={{ margin: '2px 0', fontSize: '0.85rem', color: 'var(--text-muted)' }}>{s.stage_description}</p>
                  </div>
                  <button className="btn btn-danger" onClick={() => handleDeleteStage(s.stage_id)}>Delete</button>
                </li>
              ))}
              {!stages.length && <p className="empty-state">No stages defined yet.</p>}
            </ul>
          </div>
        </div>
      )}

      {tab === 'students' && (
        <div className="card">
          <h3 style={{ marginTop: 0 }}>Enrolled Students</h3>
          <form onSubmit={handleEnrollByRoll} style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
            <input placeholder="Enroll by student ID (numeric)" value={manualRoll} onChange={(e) => setManualRoll(e.target.value)} />
            <button
              type="button"
              className="btn btn-primary"
              onClick={async () => {
                if (!manualRoll) return;
                await api.post(`/teacher/projects/${project_id}/enroll-students`, { student_ids: [Number(manualRoll)] });
                setManualRoll('');
                loadAll();
              }}
            >
              Enroll
            </button>
          </form>
          <table>
            <thead><tr><th>Name</th><th>Roll No.</th><th>Progress</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {students.map((s) => (
                <tr key={s.student_id}>
                  <td>{s.student_name}</td>
                  <td>{s.roll_number}</td>
                  <td>{s.stages_completed}/{s.total_stages}</td>
                  <td><StatusBadge status={s.enrollment_status} /></td>
                  <td><button className="btn btn-danger" onClick={() => handleRemoveStudent(s.student_id)}>Remove</button></td>
                </tr>
              ))}
              {!students.length && <tr><td colSpan={5} className="empty-state">No students enrolled yet.</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'progress' && (
        <div className="card">
          <h3 style={{ marginTop: 0 }}>Student Progress</h3>
          <table>
            <thead><tr><th>Student</th><th>Roll No.</th><th>Stages</th><th>Pending Docs</th><th>Last Submission</th></tr></thead>
            <tbody>
              {progress.map((p) => (
                <tr key={p.student_id}>
                  <td>{p.student_name}</td>
                  <td>{p.roll_number}</td>
                  <td>
                    <div className="progress-track" style={{ width: 100, display: 'inline-block', marginRight: 8 }}>
                      <div className="progress-fill" style={{ width: `${p.total_stages ? (p.stages_completed / p.total_stages) * 100 : 0}%` }} />
                    </div>
                    {p.stages_completed}/{p.total_stages}
                  </td>
                  <td>{p.pending_docs}</td>
                  <td>{p.last_submission_date ? new Date(p.last_submission_date).toLocaleDateString() : '—'}</td>
                </tr>
              ))}
              {!progress.length && <tr><td colSpan={5} className="empty-state">No enrolled students yet.</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'announcements' && (
        <div className="grid grid-2">
          <div className="card">
            <h3 style={{ marginTop: 0 }}>Post Announcement</h3>
            <form onSubmit={handlePostAnnouncement}>
              <div className="field">
                <textarea rows={4} placeholder="Write an announcement for enrolled students..." value={announcementText} onChange={(e) => setAnnouncementText(e.target.value)} />
              </div>
              <button className="btn btn-primary">Post</button>
            </form>
          </div>
          <div className="card">
            <h3 style={{ marginTop: 0 }}>Posted Announcements</h3>
            {announcements.map((a) => (
              <div key={a.announcement_id} style={{ borderBottom: '1px solid var(--border)', padding: '8px 0', display: 'flex', justifyContent: 'space-between' }}>
                <div>
                  <p style={{ margin: 0 }}>{a.announcement_text}</p>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{new Date(a.created_date).toLocaleString()}</span>
                </div>
                <button className="btn btn-danger" onClick={() => handleDeleteAnnouncement(a.announcement_id)}>Delete</button>
              </div>
            ))}
            {!announcements.length && <p className="empty-state">No announcements posted yet.</p>}
          </div>
        </div>
      )}

      {tab === 'analytics' && (
        <div className="grid grid-2">
          <div className="card stat-card">
            <div className="value">{analytics?.completion_percentage ?? 0}%</div>
            <div className="label">Overall Stage Completion</div>
          </div>
          <div className="card stat-card">
            <div className="value">{analytics?.document_approval_percentage ?? 0}%</div>
            <div className="label">Document Approval Rate</div>
          </div>
        </div>
      )}
    </Layout>
  );
}
