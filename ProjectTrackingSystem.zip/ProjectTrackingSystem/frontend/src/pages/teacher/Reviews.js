import React, { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import api, { API_BASE_URL } from '../../utils/api';
import StatusBadge from '../../components/StatusBadge';

const FILE_ORIGIN = API_BASE_URL.replace(/\/api$/, '');

export default function TeacherReviews() {
  const [projects, setProjects] = useState([]);
  const [projectId, setProjectId] = useState('');
  const [submissions, setSubmissions] = useState([]);
  const [statusFilter, setStatusFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [selected, setSelected] = useState(null);
  const [feedbackText, setFeedbackText] = useState('');
  const [correction, setCorrection] = useState('');
  const [decision, setDecision] = useState('approved');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    api.get('/teacher/projects').then((res) => {
      setProjects(res.data.projects);
      if (res.data.projects.length) setProjectId(res.data.projects[0].project_id);
    });
  }, []);

  useEffect(() => {
    if (!projectId) return;
    const params = {};
    if (statusFilter) params.status = statusFilter;
    if (typeFilter) params.document_type = typeFilter;
    api.get(`/teacher/projects/${projectId}/submissions`, { params }).then((res) => setSubmissions(res.data.submissions));
  }, [projectId, statusFilter, typeFilter]);

  function refresh() {
    const params = {};
    if (statusFilter) params.status = statusFilter;
    if (typeFilter) params.document_type = typeFilter;
    api.get(`/teacher/projects/${projectId}/submissions`, { params }).then((res) => setSubmissions(res.data.submissions));
  }

  async function handleSubmitFeedback(e) {
    e.preventDefault();
    setSubmitting(true);
    try {
      await api.post(`/teacher/submissions/${selected.submission_id}/review`, {
        status: decision,
        feedback_comment: feedbackText,
        suggested_correction: correction,
      });
      setSelected(null);
      setFeedbackText('');
      setCorrection('');
      refresh();
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Layout>
      <div className="page-header">
        <div>
          <h1>Document Review</h1>
          <p>Review student submissions and provide feedback.</p>
        </div>
      </div>

      <div className="card" style={{ marginBottom: 18, display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        <div style={{ minWidth: 200 }}>
          <label>Project</label>
          <select value={projectId} onChange={(e) => setProjectId(e.target.value)}>
            {projects.map((p) => <option key={p.project_id} value={p.project_id}>{p.project_name}</option>)}
          </select>
        </div>
        <div style={{ minWidth: 160 }}>
          <label>Status</label>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <option value="">All</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="reverted_for_correction">Revision Requested</option>
          </select>
        </div>
        <div style={{ minWidth: 160 }}>
          <label>Document Type</label>
          <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
            <option value="">All</option>
            <option value="permission_letter">Permission Letter</option>
            <option value="completion_letter">Completion Letter</option>
            <option value="survey">Survey</option>
            <option value="photos">Photos</option>
            <option value="report">Report</option>
            <option value="other">Other</option>
          </select>
        </div>
      </div>

      <div className="card">
        <table>
          <thead><tr><th>Student</th><th>Type</th><th>Version</th><th>Submitted</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {submissions.map((s) => (
              <tr key={s.submission_id}>
                <td>{s.student_name} ({s.roll_number})</td>
                <td>{s.document_type}</td>
                <td>v{s.version_number}</td>
                <td>{new Date(s.submission_date).toLocaleDateString()}</td>
                <td><StatusBadge status={s.teacher_review_status} /></td>
                <td>
                  <a href={`${FILE_ORIGIN}${s.file_url}`} target="_blank" rel="noreferrer" style={{ marginRight: 10 }}>View</a>
                  <button className="btn btn-secondary" onClick={() => { setSelected(s); setFeedbackText(s.teacher_comments || ''); }}>
                    Review
                  </button>
                </td>
              </tr>
            ))}
            {!submissions.length && <tr><td colSpan={6} className="empty-state">No submissions match these filters.</td></tr>}
          </tbody>
        </table>
      </div>

      {selected && (
        <div className="modal-overlay" onClick={() => setSelected(null)}>
          <div className="modal-box" onClick={(e) => e.stopPropagation()}>
            <h3 style={{ marginTop: 0 }}>Review Submission</h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem' }}>
              {selected.student_name} &middot; {selected.document_type} &middot; v{selected.version_number}
            </p>
            <form onSubmit={handleSubmitFeedback}>
              <div className="field">
                <label>Decision</label>
                <select value={decision} onChange={(e) => setDecision(e.target.value)}>
                  <option value="approved">Approve</option>
                  <option value="reverted_for_correction">Revert for Correction</option>
                </select>
              </div>
              <div className="field">
                <label>Comments</label>
                <textarea rows={3} value={feedbackText} onChange={(e) => setFeedbackText(e.target.value)} />
              </div>
              {decision === 'reverted_for_correction' && (
                <div className="field">
                  <label>Suggested Correction</label>
                  <textarea rows={3} value={correction} onChange={(e) => setCorrection(e.target.value)} />
                </div>
              )}
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-primary" disabled={submitting}>{submitting ? 'Submitting...' : 'Submit Feedback'}</button>
                <button type="button" className="btn btn-secondary" onClick={() => setSelected(null)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
