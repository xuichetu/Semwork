import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function LoginPage() {
  const [role, setRole] = useState('student');
  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const user = await login(loginId, password, role);
      navigate(user.role === 'teacher' ? '/teacher/dashboard' : '/student/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1>Project Tracking System</h1>
        <p className="subtitle">Sign in to manage and track academic projects</p>

        <div className="auth-toggle">
          <button type="button" className={role === 'student' ? 'active' : ''} onClick={() => setRole('student')}>
            Student
          </button>
          <button type="button" className={role === 'teacher' ? 'active' : ''} onClick={() => setRole('teacher')}>
            Teacher
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="field">
            <label>{role === 'teacher' ? 'Unique ID' : 'Roll Number or Email'}</label>
            <input
              value={loginId}
              onChange={(e) => setLoginId(e.target.value)}
              placeholder={role === 'teacher' ? 'e.g. T001' : 'e.g. CS2024001'}
              required
            />
          </div>
          <div className="field">
            <label>Password</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          <div className="field" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <input
              type="checkbox"
              style={{ width: 'auto' }}
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
            />
            <label style={{ margin: 0 }}>Remember me</label>
          </div>
          {error && <p className="error-text">{error}</p>}
          <button className="btn btn-primary" style={{ width: '100%' }} disabled={loading}>
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>
        <p style={{ textAlign: 'center', marginTop: 16, fontSize: '0.85rem' }}>
          <a href="#forgot">Forgot password?</a>
        </p>
      </div>
    </div>
  );
}
