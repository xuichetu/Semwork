import React, { useState } from 'react';
import Layout from '../../components/Layout';
import { useAuth } from '../../context/AuthContext';

export default function StudentProfile() {
  const { user } = useAuth();
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [msg, setMsg] = useState('');

  function handleChangePassword(e) {
    e.preventDefault();
    // Wire this to a dedicated /api/student/change-password endpoint when added.
    setMsg('Password change requests are sent to your teacher/admin for now.');
    setCurrentPw('');
    setNewPw('');
  }

  return (
    <Layout>
      <div className="page-header">
        <div>
          <h1>My Profile</h1>
          <p>Your account details and preferences.</p>
        </div>
      </div>

      <div className="grid grid-2">
        <div className="card">
          <h3 style={{ marginTop: 0 }}>Account Details</h3>
          <p><strong>Name:</strong> {user?.student_name}</p>
          <p><strong>Roll Number:</strong> {user?.roll_number}</p>
          <p><strong>Email:</strong> {user?.email}</p>
          <p><strong>Batch Year:</strong> {user?.batch_year}</p>
          <p><strong>Phone:</strong> {user?.phone_number}</p>
        </div>
        <div className="card">
          <h3 style={{ marginTop: 0 }}>Change Password</h3>
          <form onSubmit={handleChangePassword}>
            <div className="field">
              <label>Current Password</label>
              <input type="password" value={currentPw} onChange={(e) => setCurrentPw(e.target.value)} required />
            </div>
            <div className="field">
              <label>New Password</label>
              <input type="password" value={newPw} onChange={(e) => setNewPw(e.target.value)} required />
            </div>
            {msg && <p className="success-text">{msg}</p>}
            <button className="btn btn-primary">Update Password</button>
          </form>
        </div>
      </div>
    </Layout>
  );
}
