import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import StatusBadge from '../../components/StatusBadge';

export default function StudentProjects() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/student/projects').then((res) => setProjects(res.data.projects)).finally(() => setLoading(false));
  }, []);

  return (
    <Layout>
      <div className="page-header">
        <div>
          <h1>My Projects</h1>
          <p>All projects assigned to you by your teacher.</p>
        </div>
      </div>

      {loading ? (
        <div className="loading">Loading projects...</div>
      ) : projects.length === 0 ? (
        <div className="card empty-state">You have no assigned projects yet.</div>
      ) : (
        <div className="grid grid-2">
          {projects.map((p) => {
            const pct = p.total_stages ? Math.round((p.stages_completed / p.total_stages) * 100) : 0;
            return (
              <div className="card" key={p.project_id}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <h3 style={{ margin: '0 0 4px' }}>{p.project_name}</h3>
                  <StatusBadge status={p.status} />
                </div>
                <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem' }}>
                  Guide: {p.teacher_name} &middot; Deadline: {p.deadline ? new Date(p.deadline).toLocaleDateString() : 'N/A'}
                </p>
                <div className="progress-track" style={{ margin: '10px 0' }}>
                  <div className="progress-fill" style={{ width: `${pct}%` }} />
                </div>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                  {p.stages_completed}/{p.total_stages} stages completed
                </p>
                <Link className="btn btn-primary" to={`/student/projects/${p.project_id}`}>
                  Open Project
                </Link>
              </div>
            );
          })}
        </div>
      )}
    </Layout>
  );
}
