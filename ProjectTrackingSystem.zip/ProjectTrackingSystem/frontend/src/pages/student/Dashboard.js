import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import { useAuth } from '../../context/AuthContext';

export default function StudentDashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/student/dashboard').then((res) => setData(res.data)).finally(() => setLoading(false));
  }, []);

  return (
    <Layout>
      <div className="page-header">
        <div>
          <h1>Welcome back, {user?.student_name || 'Student'}</h1>
          <p>Here's an overview of your projects and pending work.</p>
        </div>
      </div>

      {loading ? (
        <div className="loading">Loading dashboard...</div>
      ) : (
        <>
          <div className="grid grid-3" style={{ marginBottom: 24 }}>
            <div className="card stat-card">
              <div className="value">{data?.stats?.total_projects ?? 0}</div>
              <div className="label">Total Projects</div>
            </div>
            <div className="card stat-card">
              <div className="value">{data?.stats?.pending_submissions ?? 0}</div>
              <div className="label">Documents Needing Revision</div>
            </div>
            <div className="card stat-card">
              <div className="value">{data?.stats?.completed_stages ?? 0}</div>
              <div className="label">Stages Completed</div>
            </div>
          </div>

          <div className="card">
            <h3 style={{ marginTop: 0 }}>Upcoming Deadlines</h3>
            {data?.upcomingDeadlines?.length ? (
              <table>
                <thead>
                  <tr><th>Project</th><th>Deadline</th><th></th></tr>
                </thead>
                <tbody>
                  {data.upcomingDeadlines.map((p) => (
                    <tr key={p.project_id}>
                      <td>{p.project_name}</td>
                      <td>{new Date(p.deadline).toLocaleDateString()}</td>
                      <td><Link to={`/student/projects/${p.project_id}`}>View</Link></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <p className="empty-state">No upcoming deadlines. You're all caught up!</p>
            )}
          </div>
        </>
      )}
    </Layout>
  );
}
