import React, { useEffect, useState, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import Layout from '../../components/Layout';
import api from '../../utils/api';
import { API_BASE_URL } from '../../utils/api';
import StatusBadge from '../../components/StatusBadge';

const DOC_TYPES = [
  { value: 'permission_letter', label: 'Permission Letter' },
  { value: 'completion_letter', label: 'Completion Letter' },
  { value: 'survey', label: 'Survey / Questionnaire' },
  { value: 'photos', label: 'Photos' },
  { value: 'report', label: 'Project Report' },
  { value: 'other', label: 'Other' },
];

const FILE_ORIGIN = API_BASE_URL.replace(/\/api$/, '');

export default function StudentProjectDetails() {
  const { project_id } = useParams();
  const [tab, setTab] = useState('overview');
  const [project, setProject] = useState(null);
  const [stages, setStages] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [docType, setDocType] = useState('permission_letter');
  const [file, setFile] = useState(null);
  const [uploadMsg, setUploadMsg] = useState('');
  const [uploading, setUploading] = useState(false);

  const loadAll = useCallback(async () => {
    const [p, s, a, sub] = await Promise.all([
      api.get(`/student/projects/${project_id}/details`),
      api.get(`/student/projects/${project_id}/stages`),
      api.get(`/student/projects/${project_id}/announcements`),
      api.get(`/student/projects/${project_id}/my-submissions`),
    ]);
    setProject(p.data.project);
    setStages(s.data.stages);
    setAnnouncements(a.data.announcements);
    setSubmissions(sub.data.submissions);
  }, [project_id]);

  useEffect(() => { loadAll(); }, [loadAll]);

  async function handleUpload(e) {
    e.preventDefault();
    if (!file) return setUploadMsg('Please choose a file first.');
    setUploading(true);
    setUploadMsg('');
    try {
      const formData = new FormData();
      formData.append('document_type', docType);
      formData.append('file', file);
      await api.post(`/student/projects/${project_id}/submit-document`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setUploadMsg('Document submitted successfully.');
      setFile(null);
      loadAll();
    } catch (err) {
      setUploadMsg(err.response?.data?.message || 'Upload failed.');
    } finally {
      setUploading(false);
    }
  }

  if (!project) return <Layout><div className="loading">Loading project...</div></Layout>;

  const daysLeft = project.deadline
    ? Math.ceil((new Date(project.deadline) - new Date()) / (1000 * 60 * 60 * 24))
    : null;

  return (
    <Layout>
      <div className="page-header">
        <div>
          <h1>{project.project_name}</h1>
          <p>Guide: {project.teacher_name} &middot; {project.teacher_email}</p>
        </div>
        {daysLeft !== null && (
          <div className="card" style={{ padding: '10px 16px', textAlign: 'center' }}>
            <div style={{ fontWeight: 700, fontSize: '1.2rem' }}>{daysLeft >= 0 ? daysLeft : 0}</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>days remaining</div>
          </div>
        )}
      </div>

      <div className="tabs">
        {['overview', 'stages', 'submit', 'feedback', 'announcements'].map((t) => (
          <button key={t} className={tab === t ? 'active' : ''} onClick={() => setTab(t)}>
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <div className="card">
          <h3 style={{ marginTop: 0 }}>Description</h3>
          <p>{project.project_description || 'No description provided.'}</p>
          <h3>Guidelines</h3>
          <p style={{ whiteSpace: 'pre-wrap' }}>{project.guidelines || 'No guidelines text provided.'}</p>
          {project.guidelines_file_url && (
            <a
              className="btn btn-secondary"
              href={`${FILE_ORIGIN}${project.guidelines_file_url}`}
              target="_blank"
              rel="noreferrer"
            >
              Download Guidelines Document
            </a>
          )}
        </div>
      )}

      {tab === 'stages' && (
        <div className="card">
          <h3 style={{ marginTop: 0 }}>Project Stages</h3>
          <ul className="stage-list">
            {stages.map((s) => (
              <li className="stage-item" key={s.stage_id}>
                <div
                  className={`stage-check ${
                    s.completion_status === 'completed' ? 'done' : s.completion_status === 'under_review' ? 'review' : 'pending'
                  }`}
                >
                  {s.completion_status === 'completed' ? '✓' : s.stage_number}
                </div>
                <div style={{ flex: 1 }}>
                  <strong>{s.stage_name}</strong>
                  <p style={{ margin: '2px 0', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                    {s.stage_description}
                  </p>
                  {s.teacher_feedback && (
                    <p style={{ margin: '4px 0 0', fontSize: '0.82rem', color: 'var(--navy)' }}>
                      Feedback: {s.teacher_feedback}
                    </p>
                  )}
                </div>
                <StatusBadge status={s.completion_status} />
              </li>
            ))}
            {!stages.length && <p className="empty-state">No stages have been defined yet.</p>}
          </ul>
        </div>
      )}

      {tab === 'submit' && (
        <div className="grid grid-2">
          <div className="card">
            <h3 style={{ marginTop: 0 }}>Submit a Document</h3>
            <form onSubmit={handleUpload}>
              <div className="field">
                <label>Document Type</label>
                <select value={docType} onChange={(e) => setDocType(e.target.value)}>
                  {DOC_TYPES.map((d) => <option key={d.value} value={d.value}>{d.label}</option>)}
                </select>
              </div>
              <div className="field">
                <label>File (PDF, DOCX, or Image — max 10MB)</label>
                <input type="file" accept=".pdf,.doc,.docx,image/*" onChange={(e) => setFile(e.target.files[0])} />
              </div>
              {uploadMsg && <p className={uploadMsg.includes('success') ? 'success-text' : 'error-text'}>{uploadMsg}</p>}
              <button className="btn btn-primary" disabled={uploading}>{uploading ? 'Uploading...' : 'Submit Document'}</button>
            </form>
          </div>
          <div className="card">
            <h3 style={{ marginTop: 0 }}>Submission History</h3>
            {submissions.length ? (
              <table>
                <thead><tr><th>Type</th><th>Version</th><th>Status</th></tr></thead>
                <tbody>
                  {submissions.map((s) => (
                    <tr key={s.submission_id}>
                      <td>{DOC_TYPES.find((d) => d.value === s.document_type)?.label || s.document_type}</td>
                      <td>v{s.version_number}</td>
                      <td><StatusBadge status={s.teacher_review_status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <p className="empty-state">No submissions yet.</p>
            )}
          </div>
        </div>
      )}

      {tab === 'feedback' && (
        <div className="card">
          <h3 style={{ marginTop: 0 }}>Feedback & Revision</h3>
          {submissions.filter((s) => s.teacher_comments || s.teacher_review_status !== 'pending').length ? (
            submissions.map((s) => (
              <div key={s.submission_id} className="card" style={{ marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <strong>{DOC_TYPES.find((d) => d.value === s.document_type)?.label} (v{s.version_number})</strong>
                  <StatusBadge status={s.teacher_review_status} />
                </div>
                {s.teacher_comments && <p style={{ marginBottom: 0 }}>{s.teacher_comments}</p>}
              </div>
            ))
          ) : (
            <p className="empty-state">No feedback yet. Submit a document to receive teacher feedback here.</p>
          )}
        </div>
      )}

      {tab === 'announcements' && (
        <div className="card">
          <h3 style={{ marginTop: 0 }}>Announcements</h3>
          {announcements.length ? (
            announcements.map((a) => (
              <div key={a.announcement_id} style={{ borderBottom: '1px solid var(--border)', padding: '10px 0' }}>
                <p style={{ margin: 0 }}>{a.announcement_text}</p>
                <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                  {new Date(a.created_date).toLocaleString()}
                </span>
              </div>
            ))
          ) : (
            <p className="empty-state">No announcements posted yet.</p>
          )}
        </div>
      )}
    </Layout>
  );
}
