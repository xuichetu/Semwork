import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';

import LoginPage from './pages/LoginPage';

import StudentDashboard from './pages/student/Dashboard';
import StudentProjects from './pages/student/Projects';
import StudentProjectDetails from './pages/student/ProjectDetails';
import StudentProfile from './pages/student/Profile';

import TeacherDashboard from './pages/teacher/Dashboard';
import TeacherProjects from './pages/teacher/Projects';
import TeacherProjectManage from './pages/teacher/ProjectManage';
import TeacherReviews from './pages/teacher/Reviews';
import TeacherProfile from './pages/teacher/Profile';

function ProtectedRoute({ role, children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role) return <Navigate to="/login" replace />;
  return children;
}

function AppRoutes() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />

      <Route path="/student/dashboard" element={<ProtectedRoute role="student"><StudentDashboard /></ProtectedRoute>} />
      <Route path="/student/projects" element={<ProtectedRoute role="student"><StudentProjects /></ProtectedRoute>} />
      <Route path="/student/projects/:project_id" element={<ProtectedRoute role="student"><StudentProjectDetails /></ProtectedRoute>} />
      <Route path="/student/profile" element={<ProtectedRoute role="student"><StudentProfile /></ProtectedRoute>} />

      <Route path="/teacher/dashboard" element={<ProtectedRoute role="teacher"><TeacherDashboard /></ProtectedRoute>} />
      <Route path="/teacher/projects" element={<ProtectedRoute role="teacher"><TeacherProjects /></ProtectedRoute>} />
      <Route path="/teacher/projects/:project_id" element={<ProtectedRoute role="teacher"><TeacherProjectManage /></ProtectedRoute>} />
      <Route path="/teacher/reviews" element={<ProtectedRoute role="teacher"><TeacherReviews /></ProtectedRoute>} />
      <Route path="/teacher/profile" element={<ProtectedRoute role="teacher"><TeacherProfile /></ProtectedRoute>} />

      <Route
        path="/"
        element={
          user ? (
            <Navigate to={user.role === 'teacher' ? '/teacher/dashboard' : '/student/dashboard'} replace />
          ) : (
            <Navigate to="/login" replace />
          )
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
