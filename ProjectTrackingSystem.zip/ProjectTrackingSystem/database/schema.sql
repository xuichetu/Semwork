-- Project Tracking System - MySQL Schema
-- Run: mysql -u root -p < schema.sql

CREATE DATABASE IF NOT EXISTS project_tracking_system;
USE project_tracking_system;

SET FOREIGN_KEY_CHECKS = 0;

-- A. teachers
CREATE TABLE IF NOT EXISTS teachers (
  teacher_id INT AUTO_INCREMENT PRIMARY KEY,
  unique_id VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  department VARCHAR(100),
  phone_number VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- B. students
CREATE TABLE IF NOT EXISTS students (
  student_id INT AUTO_INCREMENT PRIMARY KEY,
  roll_number VARCHAR(50) UNIQUE NOT NULL,
  student_name VARCHAR(150) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  phone_number VARCHAR(20),
  batch_year INT,
  assigned_teacher_id INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (assigned_teacher_id) REFERENCES teachers(teacher_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- C. projects
CREATE TABLE IF NOT EXISTS projects (
  project_id INT AUTO_INCREMENT PRIMARY KEY,
  project_name VARCHAR(200) NOT NULL,
  project_description TEXT,
  teacher_id INT NOT NULL,
  created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  deadline DATE,
  status ENUM('active','completed','archived') DEFAULT 'active',
  guidelines TEXT,
  guidelines_file_url VARCHAR(255),
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- D. project_stages
CREATE TABLE IF NOT EXISTS project_stages (
  stage_id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  stage_number INT NOT NULL,
  stage_name VARCHAR(150) NOT NULL,
  stage_description TEXT,
  start_date DATE,
  end_date DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(project_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- E. student_project_enrollment
CREATE TABLE IF NOT EXISTS student_project_enrollment (
  enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  project_id INT NOT NULL,
  enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  status ENUM('active','completed','dropped') DEFAULT 'active',
  UNIQUE KEY unique_enrollment (student_id, project_id),
  FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
  FOREIGN KEY (project_id) REFERENCES projects(project_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- F. student_stage_progress
CREATE TABLE IF NOT EXISTS student_stage_progress (
  progress_id INT AUTO_INCREMENT PRIMARY KEY,
  enrollment_id INT NOT NULL,
  stage_id INT NOT NULL,
  completion_status ENUM('pending','completed','under_review') DEFAULT 'pending',
  completion_date DATE,
  teacher_feedback TEXT,
  last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY unique_progress (enrollment_id, stage_id),
  FOREIGN KEY (enrollment_id) REFERENCES student_project_enrollment(enrollment_id) ON DELETE CASCADE,
  FOREIGN KEY (stage_id) REFERENCES project_stages(stage_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- G. document_submissions
CREATE TABLE IF NOT EXISTS document_submissions (
  submission_id INT AUTO_INCREMENT PRIMARY KEY,
  enrollment_id INT NOT NULL,
  stage_id INT,
  document_type ENUM('permission_letter','completion_letter','survey','photos','report','other') NOT NULL,
  file_url VARCHAR(255) NOT NULL,
  original_filename VARCHAR(255),
  version_number INT DEFAULT 1,
  submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  teacher_review_status ENUM('pending','approved','reverted_for_correction') DEFAULT 'pending',
  teacher_comments TEXT,
  is_latest BOOLEAN DEFAULT TRUE,
  FOREIGN KEY (enrollment_id) REFERENCES student_project_enrollment(enrollment_id) ON DELETE CASCADE,
  FOREIGN KEY (stage_id) REFERENCES project_stages(stage_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- H. document_feedback
CREATE TABLE IF NOT EXISTS document_feedback (
  feedback_id INT AUTO_INCREMENT PRIMARY KEY,
  submission_id INT NOT NULL,
  teacher_id INT NOT NULL,
  feedback_comment TEXT,
  suggested_correction TEXT,
  feedback_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  status ENUM('open','resolved') DEFAULT 'open',
  FOREIGN KEY (submission_id) REFERENCES document_submissions(submission_id) ON DELETE CASCADE,
  FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- I. project_announcements
CREATE TABLE IF NOT EXISTS project_announcements (
  announcement_id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  teacher_id INT NOT NULL,
  announcement_text TEXT NOT NULL,
  created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  expiry_date DATE,
  FOREIGN KEY (project_id) REFERENCES projects(project_id) ON DELETE CASCADE,
  FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id) ON DELETE CASCADE
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

-- Helpful indexes
CREATE INDEX idx_projects_teacher ON projects(teacher_id);
CREATE INDEX idx_stages_project ON project_stages(project_id);
CREATE INDEX idx_enrollment_student ON student_project_enrollment(student_id);
CREATE INDEX idx_enrollment_project ON student_project_enrollment(project_id);
CREATE INDEX idx_submissions_enrollment ON document_submissions(enrollment_id);
CREATE INDEX idx_submissions_status ON document_submissions(teacher_review_status);
