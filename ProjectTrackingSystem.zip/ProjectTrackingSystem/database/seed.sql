-- Seed data (passwords are bcrypt hash of "password123")
USE project_tracking_system;

INSERT INTO teachers (unique_id, password, full_name, email, department, phone_number)
VALUES ('T001', '$2b$10$CwTycUXWue0Thq9StjUM0uJ8Q1x8I5Ec3Q2VpQNXmXvxHmDPXWpjy', 'Dr. Anjali Deshmukh', 'anjali.deshmukh@college.edu', 'Computer Science', '9876543210');

INSERT INTO students (roll_number, student_name, email, password, phone_number, batch_year, assigned_teacher_id)
VALUES
('CS2024001', 'Rohan Patil', 'rohan.patil@college.edu', '$2b$10$CwTycUXWue0Thq9StjUM0uJ8Q1x8I5Ec3Q2VpQNXmXvxHmDPXWpjy', '9000000001', 2024, 1),
('CS2024002', 'Sneha Kulkarni', 'sneha.kulkarni@college.edu', '$2b$10$CwTycUXWue0Thq9StjUM0uJ8Q1x8I5Ec3Q2VpQNXmXvxHmDPXWpjy', '9000000002', 2024, 1);

INSERT INTO projects (project_name, project_description, teacher_id, deadline, status, guidelines)
VALUES ('Rural Water Survey Project', 'A social survey project studying rural water access.', 1, '2026-12-31', 'active', 'Please follow the college social-work project format. Submit permission letter before starting fieldwork.');

INSERT INTO project_stages (project_id, stage_number, stage_name, stage_description, start_date, end_date)
VALUES
(1, 1, 'Proposal', 'Submit project proposal and permission letter', '2026-07-01', '2026-07-15'),
(1, 2, 'Fieldwork', 'Conduct survey and collect photos', '2026-07-16', '2026-08-31'),
(1, 3, 'Report Writing', 'Compile findings into final report', '2026-09-01', '2026-09-30');

INSERT INTO student_project_enrollment (student_id, project_id, status)
VALUES (1, 1, 'active'), (2, 1, 'active');

INSERT INTO student_stage_progress (enrollment_id, stage_id, completion_status)
VALUES (1, 1, 'pending'), (1, 2, 'pending'), (1, 3, 'pending'),
       (2, 1, 'pending'), (2, 2, 'pending'), (2, 3, 'pending');
